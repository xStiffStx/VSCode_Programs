#ifndef MAZE_H
#define MAZE_H

#define filas 5
#define columnas 5

void imprimirLaberinto(int laberinto[filas][columnas]);

#endif
