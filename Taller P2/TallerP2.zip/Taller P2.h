
void operacionTransporte();
float Calc_precio_ruta(int tipo_ruta, float dis);
float calcularDescuento(float costoTotal, float dis);
void redSocial();