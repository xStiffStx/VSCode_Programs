int Login();
void operacionTransporte();
void redSocial();
void menu();